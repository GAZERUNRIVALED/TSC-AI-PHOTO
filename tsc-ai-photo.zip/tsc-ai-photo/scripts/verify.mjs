// Memeriksa bahwa file yang disajikan identik dengan file original.
//
//   npm run verify                         -> cek hasil build lokal (dist/) terhadap content/originals/
//   npm run verify -- https://situs.pages.dev  -> unduh tiap file original dari situs yang sudah online,
//                                              lalu bandingkan SHA-256, ukuran, dan dimensi dengan katalog
//
// Exit code 1 jika ada yang tidak cocok.

import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import sharp from 'sharp';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DIST = path.join(ROOT, 'dist');
const sha = (buf) => crypto.createHash('sha256').update(buf).digest('hex');

const target = process.argv[2] ? process.argv[2].replace(/\/+$/, '') : '';
let failed = 0;
const pass = (name, msg) => console.log(`  PASS  ${name}  ${msg}`);
const fail = (name, msg) => {
  failed++;
  console.log(`  FAIL  ${name}  ${msg}`);
};

let catalog;
try {
  catalog = JSON.parse(await fs.readFile(path.join(DIST, 'data', 'wallpapers.json'), 'utf8'));
} catch {
  console.error('dist/data/wallpapers.json tidak ditemukan. Jalankan "npm run build" dulu.');
  process.exit(1);
}

console.log(`\nMemeriksa ${catalog.length} wallpaper${target ? ` di ${target}` : ' (build lokal)'}\n`);

for (const wp of catalog) {
  const name = wp.downloadName;
  try {
    const source = await fs.readFile(path.join(ROOT, 'content', 'originals', wp.sourceFile));
    let served;
    if (target) {
      const res = await fetch(target + wp.original);
      if (!res.ok) {
        fail(name, `server membalas ${res.status}`);
        continue;
      }
      served = Buffer.from(await res.arrayBuffer());
    } else {
      served = await fs.readFile(path.join(DIST, wp.original.replace(/^\//, '')));
    }

    const meta = await sharp(served, { failOn: 'none' }).metadata();
    const w = meta.orientation && meta.orientation >= 5 ? meta.height : meta.width;
    const h = meta.orientation && meta.orientation >= 5 ? meta.width : meta.height;
    const problems = [];
    if (sha(served) !== sha(source)) problems.push('isi file berbeda dari content/originals');
    if (sha(served) !== wp.sha256) problems.push('checksum berbeda dari katalog');
    if (served.length !== wp.bytes) problems.push(`ukuran ${served.length} B, katalog ${wp.bytes} B`);
    if (w !== wp.width || h !== wp.height) problems.push(`dimensi ${w}x${h}, katalog ${wp.width}x${wp.height}`);
    if (problems.length) fail(name, problems.join('; '));
    else pass(name, `${wp.width}x${wp.height} ${wp.format}, ${wp.bytes} B, sha256 ${wp.sha256.slice(0, 12)}...`);
  } catch (err) {
    fail(name, err.message);
  }
}

console.log(failed ? `\n${failed} pemeriksaan GAGAL.\n` : '\nSemua file identik dengan original.\n');
process.exit(failed ? 1 : 0);
