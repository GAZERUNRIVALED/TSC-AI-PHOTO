// TSC AI PHOTO - build script
// Jalankan dengan: npm run build
//
// Yang dilakukan script ini:
//  1. Membaca content/wallpapers.json + file di content/originals/
//  2. Membaca resolusi, format, dan ukuran file dari file ASLI (otomatis)
//  3. Membuat preview kecil (WebP) + gambar OG untuk media sosial
//  4. MENYALIN file original byte-per-byte ke dist/original/ (tanpa diubah sedikit pun)
//  5. Memverifikasi hasil salinan dengan checksum SHA-256
//  6. Membuat halaman HTML statis, sitemap.xml, dan robots.txt di dist/

import fs from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import sharp from 'sharp';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const P = {
  config: path.join(ROOT, 'site.config.json'),
  data: path.join(ROOT, 'content', 'wallpapers.json'),
  originals: path.join(ROOT, 'content', 'originals'),
  homePanel: path.join(ROOT, 'content', 'home-panel'),
  pages: path.join(ROOT, 'src', 'pages'),
  statics: path.join(ROOT, 'src', 'static'),
  templates: path.join(ROOT, 'src', 'templates'),
  dist: path.join(ROOT, 'dist'),
  cache: path.join(ROOT, '.cache'),
};

const THUMB_WIDTH = 520; // lebar preview kartu (px)
const LARGE_MAX = 1800; // sisi terpanjang preview halaman detail (px)
const CACHE_VERSION = 'v2';
const BG = '#090B12';

// ---------- helper ----------

class BuildError extends Error {}
const fail = (msg) => {
  throw new BuildError(msg);
};

const esc = (value) =>
  String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');

const stripDiacritics = (s) => String(s).normalize('NFKD').replace(/[\u0300-\u036f]/g, '');

const slugify = (s) =>
  stripDiacritics(s)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');

// "dark space" -> "Dark-Space"
const prettyName = (s) =>
  stripDiacritics(s)
    .split(/[^A-Za-z0-9]+/)
    .filter(Boolean)
    .map((w) => w[0].toUpperCase() + w.slice(1))
    .join('-');

function formatBytes(bytes) {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(bytes >= 10 * 1024 * 1024 ? 1 : 2)} MB`;
}

const gcd = (a, b) => (b ? gcd(b, a % b) : a);
const COMMON_RATIOS = [
  [1, 1], [5, 4], [4, 3], [3, 2], [16, 10], [16, 9], [18, 9],
  [18.5, 9], [19, 9], [19.5, 9], [20, 9], [21, 9], [2, 1],
];

function aspectRatio(w, h) {
  const g = gcd(w, h);
  const a = w / g;
  const b = h / g;
  if (Math.max(a, b) <= 24) {
    const exact = `${a}:${b}`;
    return exact === '8:5' ? '16:10' : exact === '5:8' ? '10:16' : exact; // 16:10 lebih dikenal daripada 8:5
  }
  const long = Math.max(w, h);
  const short = Math.min(w, h);
  for (const [l, s] of COMMON_RATIOS) {
    if (Math.abs(long / short - l / s) / (l / s) < 0.006) return w >= h ? `${l}:${s}` : `${s}:${l}`;
  }
  const r = (long / short).toFixed(2);
  return w >= h ? `${r}:1` : `1:${r}`;
}

const FORMAT_LABEL = { jpeg: 'JPG', png: 'PNG', webp: 'WEBP', avif: 'AVIF', heif: 'HEIC', tiff: 'TIFF', gif: 'GIF' };

function formatDate(iso) {
  const d = new Date(`${iso}T00:00:00Z`);
  return new Intl.DateTimeFormat('en-GB', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' }).format(d);
}

function sha256(file) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    createReadStream(file)
      .on('error', reject)
      .on('data', (chunk) => hash.update(chunk))
      .on('end', () => resolve(hash.digest('hex')));
  });
}

const warnings = [];
const warn = (msg) => warnings.push(msg);

// URL dianggap "sudah diisi" jika tidak kosong dan bukan placeholder.
const isSet = (v) => typeof v === 'string' && v.trim() !== '' && !/GANTI|TIKTOK_URL|YOUTUBE_URL/i.test(v);

// Baca JSON dengan pesan galat yang jelas (salah koma/kutip adalah kesalahan paling umum).
async function readJson(file, label) {
  let text;
  try {
    text = await fs.readFile(file, 'utf8');
  } catch {
    fail(`${label} tidak ditemukan.`);
  }
  try {
    return JSON.parse(text);
  } catch (err) {
    fail(`${label} bukan JSON yang valid: ${err.message}\n  Periksa tanda koma di antara entri, tanda kutip ganda, dan kurung { } [ ].`);
  }
}

// Cloudflare (Linux) membedakan "Isabel.PNG" dan "isabel.png", sedangkan Windows/macOS tidak.
// Pemeriksaan ini memastikan nama di data cocok PERSIS dengan nama file, supaya tidak lolos di
// komputer lalu gagal setelah deploy.
async function findExact(baseDir, rel) {
  const parts = path.normalize(rel).split(path.sep).filter(Boolean);
  let dir = baseDir;
  for (const part of parts) {
    let names;
    try {
      names = await fs.readdir(dir);
    } catch {
      return { ok: false };
    }
    if (names.includes(part)) {
      dir = path.join(dir, part);
      continue;
    }
    return { ok: false, hint: names.find((n) => n.toLowerCase() === part.toLowerCase()) };
  }
  return { ok: true };
}

const missingFileMessage = (label, file, found) =>
  `${label}: file "${file}" tidak ditemukan di content/originals/.` +
  (found.hint
    ? ` Ada file bernama "${found.hint}", tetapi huruf besar/kecilnya berbeda. Nama harus sama persis karena server Cloudflare membedakannya.`
    : ' Periksa ejaan, huruf besar/kecil, dan ekstensi.');

// Batas Cloudflare Pages: 25 MiB per file.
const MAX_PAGES_FILE = 25 * 1024 * 1024;
const checkPagesLimit = (label, file, bytes) => {
  if (bytes > MAX_PAGES_FILE) {
    warn(`${label}: "${file}" berukuran ${(bytes / 1048576).toFixed(1)} MiB dan MELEBIHI batas Cloudflare Pages 25 MiB per file. Deploy akan gagal sampai file ini diperkecil atau disimpan di tempat lain.`);
  }
};

const exists = (p) => fs.access(p).then(() => true, () => false);

// Ganti {{kunci}} (nilai di-escape). Blok HTML mentah memakai penanda <!--NAMA-->.
const render = (html, vars) => html.replace(/\{\{(\w+)\}\}/g, (_, key) => esc(vars[key] ?? ''));
const inject = (html, marker, value) => html.split(`<!--${marker}-->`).join(value);

// ---------- variasi ukuran (opsional) ----------

const RATIO_TOLERANCE = 0.02; // selisih rasio yang masih dianggap cocok dengan kategori (2%)

// Dipakai bila site.config.json belum punya "variantTypes". Urutan = urutan tampil di halaman detail.
const DEFAULT_VARIANT_TYPES = {
  mobile: { label: 'Mobile', ratio: [9, 16] },
  'tablet-portrait': { label: 'Tablet Portrait', ratio: [3, 4] },
  'tablet-landscape': { label: 'Tablet Landscape', ratio: [4, 3] },
  'modern-laptop': { label: 'Modern Laptop', ratio: [16, 10] },
  'desktop-standard-laptop': { label: 'Desktop & Standard Laptop', ratio: [16, 9] },
};

function getVariantTypes(cfg) {
  const types = cfg.variantTypes || DEFAULT_VARIANT_TYPES;
  for (const [id, t] of Object.entries(types)) {
    const okRatio = Array.isArray(t.ratio) && t.ratio.length === 2 && t.ratio.every((n) => typeof n === 'number' && n > 0);
    if (!/^[a-z0-9-]+$/.test(id) || !t.label || !okRatio) {
      fail(`site.config.json: "variantTypes.${id}" harus berisi "label" dan "ratio" seperti [9, 16], dan id hanya huruf kecil/angka/strip.`);
    }
  }
  return types;
}

async function processVariant(base, id, raw, type, cfg, usedNames, seenHashes, parentLabel) {
  const label = `${parentLabel} (${base.title}), varian "${id}"`;
  const spec = typeof raw === 'string' ? { file: raw } : raw;
  if (!spec || typeof spec !== 'object' || typeof spec.file !== 'string' || !spec.file.trim()) {
    fail(`${label}: field "file" wajib diisi, contoh { "file": "nama-file.png" }.`);
  }
  const rel = path.normalize(spec.file.trim());
  if (path.isAbsolute(rel) || rel.split(path.sep).includes('..')) fail(`${label}: "file" harus berada di dalam content/originals/.`);
  const src = path.join(P.originals, rel);
  const found = await findExact(P.originals, rel);
  if (!found.ok) fail(missingFileMessage(label, spec.file, found));
  const stat = await fs.stat(src);
  checkPagesLimit(label, spec.file, stat.size);
  const meta = await sharp(src, { failOn: 'none' }).metadata();
  if (!meta.width || !meta.height) fail(`${label}: "${spec.file}" bukan gambar yang valid.`);
  let width = meta.width;
  let height = meta.height;
  if (meta.orientation && meta.orientation >= 5) [width, height] = [height, width];

  // Metadata selalu dari file asli. Angka di data (opsional) hanya dipakai untuk mendeteksi salah file.
  if ((spec.width !== undefined && spec.width !== width) || (spec.height !== undefined && spec.height !== height)) {
    fail(`${label}: ukuran di data (${spec.width}×${spec.height}) tidak cocok dengan file sebenarnya (${width}×${height}).`);
  }
  const [rw, rh] = type.ratio;
  const target = rw / rh;
  if (Math.abs(width / height - target) / target > RATIO_TOLERANCE) {
    fail(
      `${label}: rasio file ${width}×${height} (${aspectRatio(width, height)}) tidak sesuai kategori "${type.label}" (${rw}:${rh}). ` +
        'Pastikan file ditaruh di kategori yang benar.',
    );
  }

  const ext = path.extname(rel).toLowerCase();
  const format = FORMAT_LABEL[meta.format] || (meta.format || ext.slice(1)).toUpperCase();
  const downloadName = [
    cfg.filePrefix || 'TSC',
    prettyName(base.character) || 'Wallpaper',
    prettyName(base.title) || base.slug,
    prettyName(id),
    `${width}x${height}`,
  ].join('-') + ext;
  if (usedNames.has(downloadName)) fail(`${label}: nama file download "${downloadName}" bentuknya sama dengan entri lain.`);
  usedNames.add(downloadName);

  // Preview besar (hanya tampilan). Disimpan di .cache seperti preview lain.
  const key = crypto.createHash('sha1').update(`${stat.size}:${stat.mtimeMs}:${CACHE_VERSION}`).digest('hex').slice(0, 10);
  const previewName = `${base.slug}-${id}-${key}-large.webp`;
  const cachedPreview = path.join(P.cache, previewName);
  if (!(await exists(cachedPreview))) {
    await fs.mkdir(P.cache, { recursive: true });
    await sharp(src, { failOn: 'none' })
      .rotate()
      .resize({ width: LARGE_MAX, height: LARGE_MAX, fit: 'inside', withoutEnlargement: true })
      .webp({ quality: 82 })
      .toFile(cachedPreview);
  }
  await fs.copyFile(cachedPreview, path.join(P.dist, 'previews', previewName));

  // FILE ORIGINAL versi ini: disalin apa adanya + verifikasi checksum
  const dest = path.join(P.dist, 'original', downloadName);
  await fs.copyFile(src, dest);
  const [hashSrc, hashDest] = await Promise.all([sha256(src), sha256(dest)]);
  if (hashSrc !== hashDest) fail(`File original "${spec.file}" berubah saat disalin. Build dibatalkan.`);
  if (seenHashes.has(hashSrc)) {
    fail(
      `${label}: isi file sama persis dengan versi "${seenHashes.get(hashSrc)}". ` +
        'Setiap versi harus gambar yang memang dibuat untuk rasionya. Jangan menduplikasi satu gambar.',
    );
  }
  seenHashes.set(hashSrc, id);

  const scaleLarge = Math.min(1, LARGE_MAX / Math.max(width, height));
  return {
    id,
    label: type.label,
    file: spec.file.trim(),
    downloadName,
    width,
    height,
    resolution: `${width} × ${height} px`,
    resolutionShort: `${width}×${height}`,
    ratio: aspectRatio(width, height),
    format,
    mime: meta.format === 'jpeg' ? 'image/jpeg' : `image/${meta.format}`,
    bytes: stat.size,
    size: formatBytes(stat.size),
    sha256: hashSrc,
    download: `/original/${downloadName}`,
    large: `/previews/${previewName}`,
    largeW: Math.round(width * scaleLarge),
    largeH: Math.round(height * scaleLarge),
  };
}

// ---------- wallpaper ----------

async function processWallpaper(entry, index, cfg, usedSlugs, usedNames, variantTypes) {
  const label = `wallpapers.json entri #${index + 1}`;
  for (const key of ['title', 'character', 'file']) {
    if (!entry[key] || typeof entry[key] !== 'string') fail(`${label}: field "${key}" wajib diisi.`);
  }
  if (entry.tags !== undefined && !(Array.isArray(entry.tags) && entry.tags.every((t) => typeof t === 'string'))) {
    fail(`${label}: "tags" harus berupa daftar teks, contoh ["space", "dark"].`);
  }
  const artworkTypes = cfg.artworkTypes || { 'ai-generated': 'AI-generated artwork' };
  const artwork = entry.artwork || 'ai-generated';
  if (!artworkTypes[artwork]) {
    fail(`${label}: "artwork" harus salah satu dari: ${Object.keys(artworkTypes).join(', ')}.`);
  }

  const src = path.join(P.originals, entry.file);
  const found = await findExact(P.originals, entry.file);
  if (!found.ok) fail(missingFileMessage(label, entry.file, found));
  const stat = await fs.stat(src);
  checkPagesLimit(label, entry.file, stat.size);

  const slug = slugify(entry.slug || `${entry.character} ${entry.title}`);
  if (!slug) fail(`${label}: tidak bisa membuat slug dari judul/karakter. Isi field "slug" manual.`);
  if (usedSlugs.has(slug)) fail(`${label}: slug "${slug}" dipakai dua kali. Beri field "slug" yang berbeda.`);
  usedSlugs.add(slug);

  // Baca metadata dari file ASLI
  const meta = await sharp(src, { failOn: 'none' }).metadata();
  if (!meta.width || !meta.height) fail(`${label}: "${entry.file}" bukan gambar yang valid.`);
  let width = meta.width;
  let height = meta.height;
  if (meta.orientation && meta.orientation >= 5) [width, height] = [height, width]; // EXIF diputar 90 derajat

  const ext = path.extname(entry.file).toLowerCase();
  const format = FORMAT_LABEL[meta.format] || (meta.format || ext.slice(1)).toUpperCase();

  const downloadName = [
    cfg.filePrefix || 'TSC',
    prettyName(entry.character) || 'Wallpaper',
    prettyName(entry.title) || slug,
    `${width}x${height}`,
  ].join('-') + ext;
  if (usedNames.has(downloadName)) fail(`${label}: nama file download "${downloadName}" bentuknya sama dengan entri lain.`);
  usedNames.add(downloadName);

  // Preview (boleh kecil). Dibuat sekali lalu disimpan di .cache supaya build berikutnya cepat.
  const key = crypto.createHash('sha1').update(`${stat.size}:${stat.mtimeMs}:${CACHE_VERSION}`).digest('hex').slice(0, 10);
  const names = {
    thumb: `${slug}-${key}-thumb.webp`,
    large: `${slug}-${key}-large.webp`,
    og: `${slug}-${key}.jpg`,
  };
  const cached = {
    thumb: path.join(P.cache, names.thumb),
    large: path.join(P.cache, names.large),
    og: path.join(P.cache, names.og),
  };
  const haveCache = (await Promise.all(Object.values(cached).map(exists))).every(Boolean);

  if (!haveCache) {
    await fs.mkdir(P.cache, { recursive: true });
    const base = sharp(src, { failOn: 'none' }).rotate(); // rotate() = ikuti orientasi EXIF untuk preview saja
    await Promise.all([
      base.clone().resize({ width: THUMB_WIDTH, withoutEnlargement: true }).webp({ quality: 76 }).toFile(cached.thumb),
      base
        .clone()
        .resize({ width: LARGE_MAX, height: LARGE_MAX, fit: 'inside', withoutEnlargement: true })
        .webp({ quality: 82 })
        .toFile(cached.large),
      base
        .clone()
        .flatten({ background: BG })
        .resize(1200, 630, { fit: 'contain', background: BG })
        .jpeg({ quality: 82, mozjpeg: true })
        .toFile(cached.og),
    ]);
  }
  await fs.copyFile(cached.thumb, path.join(P.dist, 'previews', names.thumb));
  await fs.copyFile(cached.large, path.join(P.dist, 'previews', names.large));
  await fs.copyFile(cached.og, path.join(P.dist, 'og', names.og));

  // FILE ORIGINAL: disalin apa adanya, lalu diverifikasi dengan checksum
  const dest = path.join(P.dist, 'original', downloadName);
  await fs.copyFile(src, dest);
  const [hashSrc, hashDest] = await Promise.all([sha256(src), sha256(dest)]);
  if (hashSrc !== hashDest) fail(`File original "${entry.file}" berubah saat disalin. Build dibatalkan.`);

  const scaleThumb = Math.min(1, THUMB_WIDTH / width);
  const scaleLarge = Math.min(1, LARGE_MAX / Math.max(width, height));
  const date = entry.date && /^\d{4}-\d{2}-\d{2}$/.test(entry.date) ? entry.date : stat.mtime.toISOString().slice(0, 10);

  const result = {
    slug,
    title: entry.title.trim(),
    character: entry.character.trim(),
    description: (entry.description || '').trim(),
    category: (entry.category || '').trim(),
    tags: (entry.tags || []).map((t) => t.trim()).filter(Boolean),
    featured: entry.featured === true,
    artwork,
    artworkLabel: artworkTypes[artwork],
    credit: (entry.credit || '').trim(),
    date,
    dateLabel: formatDate(date),
    file: entry.file,
    downloadName,
    width,
    height,
    resolution: `${width} × ${height} px`,
    resolutionShort: `${width}×${height}`,
    ratio: aspectRatio(width, height),
    format,
    mime: meta.format === 'jpeg' ? 'image/jpeg' : `image/${meta.format}`,
    bytes: stat.size,
    size: formatBytes(stat.size),
    sha256: hashSrc,
    url: `/wallpaper/${slug}`,
    download: `/original/${downloadName}`,
    thumb: `/previews/${names.thumb}`,
    thumbW: Math.round(width * scaleThumb),
    thumbH: Math.round(height * scaleThumb),
    large: `/previews/${names.large}`,
    largeW: Math.round(width * scaleLarge),
    largeH: Math.round(height * scaleLarge),
    og: `/og/${names.og}`,
  };

  // Variasi ukuran (opsional). Tanpa "variants", perilakunya sama seperti sebelumnya.
  result.variants = [];
  if (entry.variants !== undefined && entry.variants !== null) {
    if (typeof entry.variants !== 'object' || Array.isArray(entry.variants)) {
      fail(`${label}: "variants" harus berupa objek, contoh { "mobile": { "file": "nama-file.png" } }.`);
    }
    const unknown = Object.keys(entry.variants).filter((id) => !variantTypes[id]);
    if (unknown.length) {
      fail(`${label}: id varian tidak dikenal: ${unknown.join(', ')}. Id yang valid: ${Object.keys(variantTypes).join(', ')}.`);
    }
    const seenHashes = new Map([[hashSrc, 'original']]);
    for (const id of Object.keys(variantTypes)) {
      if (entry.variants[id] === undefined || entry.variants[id] === null) continue; // tidak tersedia = tidak ditampilkan
      result.variants.push(await processVariant(result, id, entry.variants[id], variantTypes[id], cfg, usedNames, seenHashes, label));
    }
  }
  return result;
}

// ---------- panel gambar di Home ----------

async function processHomePanel(cfg) {
  const hp = cfg.homePanel || {};
  const base = { alt: hp.alt || 'Featured artwork', caption: (hp.caption || '').trim() };
  if (!hp.image) return { ...base, empty: true };

  const src = path.join(P.homePanel, hp.image);
  if (!(await exists(src))) {
    warn(`homePanel.image "${hp.image}" tidak ditemukan di content/home-panel/. Home memakai placeholder.`);
    return { ...base, empty: true };
  }
  const buf = await fs.readFile(src);
  const hash = crypto.createHash('sha1').update(buf).digest('hex').slice(0, 10);
  const name = `panel-${hash}.webp`;
  // Hanya salinan tampilan. Rasio asli dipertahankan, transparansi PNG tetap ada.
  const info = await sharp(buf, { failOn: 'none' })
    .rotate()
    .resize({ width: 1400, withoutEnlargement: true })
    .webp({ quality: 86 })
    .toFile(path.join(P.dist, 'home-panel', name));
  return { ...base, empty: false, src: `/home-panel/${name}`, width: info.width, height: info.height };
}

// ---------- potongan HTML ----------

// Data tiap versi untuk pemilih di halaman detail. "original" = file utama (field "file") di entri wallpaper.
function versionList(wp) {
  const pick = (v, id, label, alt) => ({
    id, label, alt,
    width: v.width, height: v.height, resolution: v.resolution, ratio: v.ratio, format: v.format,
    size: v.size, bytes: v.bytes, sha256: v.sha256,
    download: v.download, downloadName: v.downloadName,
    large: v.large, largeW: v.largeW, largeH: v.largeH,
  });
  return [
    pick(wp, 'original', 'Original', `${wp.character} - ${wp.title} wallpaper`),
    ...wp.variants.map((v) => pick(v, v.id, v.label, `${wp.character} - ${wp.title}, ${v.label} version wallpaper`)),
  ];
}

// Tanpa variasi: tidak ada pemilih sama sekali (halaman sama seperti sebelumnya).
function versionsHtml(wp) {
  if (!wp.variants.length) return '';
  const versions = versionList(wp);
  const options = versions
    .map(
      (v, i) => `<label class="version-option">
        <input class="sr-only" type="radio" name="version" value="${esc(v.id)}"${i === 0 ? ' checked' : ''}>
        <span class="v-label">${esc(v.label)}</span>
        <span class="v-meta">${esc(v.ratio)}</span>
      </label>`,
    )
    .join('\n      ');
  const links = versions
    .map(
      (v) =>
        `<li><a href="${v.download}" download="${esc(v.downloadName)}" rel="nofollow">${esc(v.label)}: ${esc(v.resolution)}, ${esc(v.format)}, ${esc(v.size)}</a></li>`,
    )
    .join('\n    ');
  return `<fieldset class="versions" data-versions>
      <legend>Choose a version</legend>
      <div class="version-options">
      ${options}
      </div>
      <p class="version-hint">Each version is a separate original file made for that screen shape.</p>
    </fieldset>
    <script type="application/json" id="versions-data">${JSON.stringify(versions).replace(/</g, '\\u003c')}</script>
    <noscript>
      <ul class="version-links">
    ${links}
      </ul>
    </noscript>`;
}

const altText = (wp) => `${wp.character} - ${wp.title}${wp.category ? `, ${wp.category}` : ''} wallpaper preview`;

function panelHtml(panel) {
  if (panel.empty) {
    return `<figure class="glass-panel glass-panel--empty" aria-hidden="true">
  <div class="glass-inner">
    <svg class="glass-ph" viewBox="0 0 240 300" focusable="false">
      <defs><linearGradient id="phg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#C4B5FD"/><stop offset="1" stop-color="#A78BFA"/></linearGradient></defs>
      <rect x="40" y="20" width="160" height="260" rx="16" fill="none" stroke="#2B293B" stroke-width="2"/>
      <path d="M120 70l9 56 45 24-45 24-9 56-9-56-45-24 45-24z" fill="url(#phg)" opacity=".85"/>
    </svg>
  </div>
</figure>`;
  }
  return `<figure class="glass-panel">
  <div class="glass-inner">
    <img src="${panel.src}" width="${panel.width}" height="${panel.height}" alt="${esc(panel.alt)}" decoding="async" fetchpriority="high">
  </div>${panel.caption ? `\n  <figcaption>${esc(panel.caption)}</figcaption>` : ''}
</figure>`;
}

function cardHtml(wp, headingTag = 'h2') {
  const search = [wp.title, wp.character, wp.category, ...wp.tags].join(' ').toLowerCase();
  return `<article class="card" data-character="${esc(wp.character)}" data-category="${esc(wp.category)}" data-search="${esc(search)}">
  <div class="card-media" style="--ar:${wp.width}/${wp.height}">
    <img src="${wp.thumb}" width="${wp.thumbW}" height="${wp.thumbH}" alt="${esc(altText(wp))}" loading="lazy" decoding="async">
    <span class="media-fallback" hidden>Preview unavailable</span>
  </div>
  <div class="card-body">
    <p class="card-meta"><span class="card-char">${esc(wp.character)}</span>${wp.category ? `<span class="pill">${esc(wp.category)}</span>` : ''}</p>
    <${headingTag} class="card-title"><a class="card-link" href="${wp.url}">${esc(wp.title)}</a></${headingTag}>
    <dl class="specs">
      <div><dt>Resolution</dt><dd>${esc(wp.resolutionShort)}</dd></div>
      <div><dt>Ratio</dt><dd>${esc(wp.ratio)}</dd></div>
      <div><dt>File size</dt><dd>${esc(wp.size)}</dd></div>
    </dl>
    <div class="card-actions">
      <a class="btn btn-primary btn-sm" href="${wp.download}" download="${esc(wp.downloadName)}" rel="nofollow" data-original data-bytes="${wp.bytes}">Download Full Size</a>
    </div>
  </div>
</article>`;
}

function chipGroup(groupKey, label, values, allLabel) {
  if (values.length < 2) return '';
  const chips = values
    .map((v) => `<button type="button" class="chip" data-group="${groupKey}" data-value="${esc(v)}" aria-pressed="false">${esc(v)}</button>`)
    .join('\n      ');
  return `<div class="filter-group" role="group" aria-label="${label}">
      <button type="button" class="chip is-active" data-group="${groupKey}" data-value="" aria-pressed="true">${allLabel}</button>
      ${chips}
    </div>`;
}

function toolsHtml(list) {
  if (!list.length) return '';
  const sortAlpha = (arr) => [...new Set(arr)].filter(Boolean).sort((a, b) => a.localeCompare(b));
  const categories = sortAlpha(list.map((w) => w.category));
  const characters = sortAlpha(list.map((w) => w.character));
  return `<div class="tools" data-tools>
    <label class="search">
      <span class="sr-only">Search wallpapers</span>
      <input type="search" id="q" placeholder="Search by title, character or tag" autocomplete="off" enterkeyhint="search">
    </label>
    ${chipGroup('category', 'Filter by category', categories, 'All categories')}
    ${chipGroup('character', 'Filter by character', characters, 'All characters')}
  </div>`;
}

function homeSectionHtml(title, list, { moreLink = false, id }) {
  if (!list.length) return '';
  return `<section class="wrap section" aria-labelledby="${id}">
  <div class="section-head">
    <h2 class="section-title text-glow-accent" id="${id}">${esc(title)}</h2>${
      moreLink ? '\n    <a class="more-link text-glow-hover" href="/gallery">View all wallpapers</a>' : ''
    }
  </div>
  <div class="grid">
    ${list.map((wp) => cardHtml(wp, 'h3')).join('\n')}
  </div>
</section>`;
}

// Ikon navigasi (satu set, gaya garis konsisten). Dekoratif: label teks tetap ada.
const NAV_ICONS = {
  home: '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v9.5c0 .3.2.5.5.5h4v-6h4v6h4c.3 0 .5-.2.5-.5V10"/>',
  gallery: '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
  about: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5.5"/><path d="M12 7.6h.01"/>',
};

function navHtml(active) {
  const items = [
    ['home', 'Home', '/'],
    ['gallery', 'Gallery', '/gallery'],
    ['about', 'About', '/about'],
  ];
  return items
    .map(
      ([key, label, href]) =>
        `<a href="${href}"${key === active ? ' aria-current="page"' : ''}><span class="nav-icon"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">${NAV_ICONS[key]}</svg></span><span class="nav-label">${label}</span></a>`,
    )
    .join('\n  ');
}

function socialLinks(cfg) {
  const links = [];
  if (isSet(cfg.tiktok)) links.push(['TikTok', cfg.tiktok]);
  if (isSet(cfg.youtube)) links.push(['YouTube', cfg.youtube]);
  return links;
}

const extLink = (label, href, cls = '') =>
  `<a${cls ? ` class="${cls}"` : ''} href="${esc(href)}" target="_blank" rel="noopener noreferrer">${esc(label)}</a>`;

function headHtml(cfg, { title, description, urlPath, image, imageAlt, noindex = false, type = 'website', extra = '' }) {
  // URL absolut hanya dipakai kalau domain produksi sudah diisi di siteUrl.
  const site = (cfg.siteUrl || '').replace(/\/+$/, '');
  const url = site ? `${site}${urlPath}` : '';
  const img = site && image ? site + image : '';
  const lines = [
    `<title>${esc(title)}</title>`,
    `<meta name="description" content="${esc(description)}">`,
    url ? `<link rel="canonical" href="${esc(url)}">` : '',
    noindex ? '<meta name="robots" content="noindex">' : '',
    '<meta name="theme-color" content="#090B12">',
    '<meta name="color-scheme" content="dark">',
    '<link rel="icon" href="/favicon.svg" type="image/svg+xml">',
    '<link rel="icon" href="/favicon-32.png" sizes="32x32" type="image/png">',
    '<link rel="apple-touch-icon" href="/apple-touch-icon.png">',
    `<meta property="og:site_name" content="${esc(cfg.siteName)}">`,
    `<meta property="og:type" content="${type}">`,
    `<meta property="og:title" content="${esc(title)}">`,
    `<meta property="og:description" content="${esc(description)}">`,
    url ? `<meta property="og:url" content="${esc(url)}">` : '',
    img ? `<meta property="og:image" content="${esc(img)}">` : '',
    img ? '<meta property="og:image:width" content="1200">' : '',
    img ? '<meta property="og:image:height" content="630">' : '',
    img ? `<meta property="og:image:alt" content="${esc(imageAlt || title)}">` : '',
    `<meta name="twitter:card" content="${img ? 'summary_large_image' : 'summary'}">`,
    `<meta name="twitter:title" content="${esc(title)}">`,
    `<meta name="twitter:description" content="${esc(description)}">`,
    img ? `<meta name="twitter:image" content="${esc(img)}">` : '',
    extra,
  ];
  return lines.filter(Boolean).join('\n');
}

// ---------- main ----------

async function main() {
  const started = Date.now();
  const cfg = await readJson(P.config, 'site.config.json');
  const entries = await readJson(P.data, 'content/wallpapers.json');
  if (!Array.isArray(entries)) fail('content/wallpapers.json harus berupa array [ ... ].');

  const siteUrl = (cfg.siteUrl || '').replace(/\/+$/, '');
  if (siteUrl && !/^https?:\/\//.test(siteUrl)) fail('site.config.json: "siteUrl" harus diawali https://');
  if (!siteUrl) warn('siteUrl belum diisi: canonical, og:url, og:image, dan sitemap dilewati sampai domain publik diketahui.');
  if (!isSet(cfg.tiktok)) warn('Link TikTok belum diisi di site.config.json ("tiktok"). Tombol/link TikTok disembunyikan.');
  if (!isSet(cfg.youtube)) warn('Link YouTube belum diisi di site.config.json ("youtube"). Link YouTube disembunyikan.');

  // folder output bersih
  await fs.rm(P.dist, { recursive: true, force: true });
  for (const dir of ['previews', 'og', 'original', 'wallpaper', 'data', 'home-panel']) {
    await fs.mkdir(path.join(P.dist, dir), { recursive: true });
  }
  await fs.cp(P.statics, P.dist, { recursive: true });

  // ikon (dibuat dari favicon.svg)
  const svg = await fs.readFile(path.join(P.statics, 'favicon.svg'));
  await sharp(svg, { density: 512 }).resize(180, 180).png().toFile(path.join(P.dist, 'apple-touch-icon.png'));
  await sharp(svg, { density: 512 }).resize(32, 32).png().toFile(path.join(P.dist, 'favicon-32.png'));

  // proses semua wallpaper
  const usedSlugs = new Set();
  const usedNames = new Set();
  const variantTypes = getVariantTypes(cfg);
  const processed = [];
  for (const [i, entry] of entries.entries()) {
    processed.push(await processWallpaper(entry, i, cfg, usedSlugs, usedNames, variantTypes));
  }
  // terbaru dulu (urutan array dipakai jika tanggal sama)
  const wallpapers = processed
    .map((wp, i) => ({ wp, i }))
    .sort((a, b) => b.wp.date.localeCompare(a.wp.date) || a.i - b.i)
    .map(({ wp }) => wp);

  const panel = await processHomePanel(cfg);

  // katalog publik (dipakai juga oleh scripts/verify.mjs)
  await fs.writeFile(
    path.join(P.dist, 'data', 'wallpapers.json'),
    JSON.stringify(
      wallpapers.map((wp) => ({
        slug: wp.slug,
        title: wp.title,
        character: wp.character,
        category: wp.category,
        tags: wp.tags,
        featured: wp.featured,
        artwork: wp.artwork,
        description: wp.description,
        date: wp.date,
        original: wp.download,
        preview: wp.thumb,
        previewLarge: wp.large,
        downloadName: wp.downloadName,
        sourceFile: wp.file,
        variants: wp.variants.map((v) => ({
          id: v.id,
          label: v.label,
          original: v.download,
          previewLarge: v.large,
          downloadName: v.downloadName,
          sourceFile: v.file,
          width: v.width,
          height: v.height,
          ratio: v.ratio,
          format: v.format,
          bytes: v.bytes,
          sha256: v.sha256,
        })),
        width: wp.width,
        height: wp.height,
        ratio: wp.ratio,
        format: wp.format,
        bytes: wp.bytes,
        sha256: wp.sha256,
      })),
      null,
      2,
    ),
  );

  // template
  const read = (dir, name) => fs.readFile(path.join(dir, name), 'utf8');
  const layout = await read(P.templates, 'layout.html');
  const detailTpl = await read(P.templates, 'wallpaper.html');

  const socials = socialLinks(cfg);
  const baseVars = {
    siteName: cfg.siteName,
    tagline: cfg.tagline,
    year: new Date().getFullYear(),
    count: wallpapers.length,
    pageSize: Math.max(1, Number(cfg.galleryPageSize) || 12),
    usageNote: cfg.usageNote || '',
    ipNotice: cfg.ipNotice || '',
    disclaimer: cfg.disclaimer || '',
  };

  const latestOg = wallpapers[0]?.og;
  const wrapPage = (content, nav, headOptions) => {
    let html = layout;
    html = inject(html, 'HEAD', headHtml(cfg, headOptions));
    html = inject(html, 'NAV', navHtml(nav));
    html = inject(html, 'SOCIAL_LINKS', socials.map(([l, h]) => extLink(l, h)).join('\n      '));
    html = inject(html, 'CONTENT', content);
    return render(html, baseVars);
  };

  const write = async (rel, html) => {
    const out = path.join(P.dist, rel);
    await fs.mkdir(path.dirname(out), { recursive: true });
    await fs.writeFile(out, html);
  };

  // HOME
  {
    let page = await read(P.pages, 'home.html');
    const featured = wallpapers.filter((w) => w.featured).slice(0, 6);
    const recent = wallpapers.slice(0, Math.max(1, Number(cfg.homeRecentCount) || 4));
    const tiktok = isSet(cfg.tiktok) ? extLink('Follow on TikTok', cfg.tiktok, 'btn btn-ghost btn-lg') : '';
    page = inject(page, 'HERO_SOCIAL', tiktok);
    page = inject(page, 'HERO_PANEL', panelHtml(panel));
    page = inject(page, 'FEATURED', homeSectionHtml('Featured wallpapers', featured, { id: 'featured-title' }));
    page = inject(page, 'RECENT', homeSectionHtml('Recently added', recent, { moreLink: true, id: 'recent-title' }));
    page = render(page, baseVars);
    await write(
      'index.html',
      wrapPage(page, 'home', {
        title: `${cfg.siteName} - ${cfg.tagline}`,
        description: cfg.description,
        urlPath: '/',
        image: latestOg,
        imageAlt: wallpapers[0] ? altText(wallpapers[0]) : cfg.siteName,
      }),
    );
  }

  // GALLERY
  {
    let page = await read(P.pages, 'gallery.html');
    const cards = wallpapers.length
      ? wallpapers.map((wp) => cardHtml(wp)).join('\n')
      : '<p class="empty">No wallpapers yet. Check back soon.</p>';
    page = inject(page, 'TOOLS', toolsHtml(wallpapers));
    page = inject(page, 'GALLERY_CARDS', cards);
    page = render(page, baseVars);
    await write(
      'gallery.html',
      wrapPage(page, 'gallery', {
        title: `Gallery - ${cfg.siteName}`,
        description: `Browse ${wallpapers.length} AI wallpapers and download each one in its original resolution.`,
        urlPath: '/gallery',
        image: latestOg,
        imageAlt: cfg.siteName,
      }),
    );
  }

  // ABOUT
  {
    let page = await read(P.pages, 'about.html');
    const credits = (cfg.credits || []).map((c) => `<li>${esc(c)}</li>`).join('\n');
    const types = Object.values(cfg.artworkTypes || {}).map((t) => `<li>${esc(t)}</li>`).join('\n');
    const follow = socials.length
      ? `<h2>Follow</h2>
  <p>New wallpapers are shared on social media first.</p>
  <p class="inline-actions">${socials
    .map(([l, h], i) => extLink(l, h, `btn ${i === 0 ? 'btn-primary' : 'btn-ghost'}`))
    .join('\n    ')}</p>`
      : '';
    page = inject(page, 'CREDITS', credits);
    page = inject(page, 'ARTWORK_TYPES', types);
    page = inject(page, 'FOLLOW', follow);
    page = render(page, baseVars);
    await write(
      'about.html',
      wrapPage(page, 'about', {
        title: `About - ${cfg.siteName}`,
        description: `${cfg.siteName} is an independent fan-made gallery of AI wallpapers, starting with The Spike Cross. Learn how downloads and credits work.`,
        urlPath: '/about',
        image: latestOg,
        imageAlt: cfg.siteName,
      }),
    );
  }

  // 404
  {
    let page = await read(P.pages, '404.html');
    const latest = wallpapers.slice(0, 3);
    page = inject(
      page,
      'LATEST_LINKS',
      latest.length
        ? `<h2 class="not-found-sub">Latest wallpapers</h2>
  <ul class="link-list">
    ${latest.map((wp) => `<li><a href="${wp.url}">${esc(wp.character)} - ${esc(wp.title)}</a></li>`).join('\n    ')}
  </ul>`
        : '',
    );
    page = render(page, baseVars);
    await write(
      '404.html',
      wrapPage(page, '', {
        title: `Page not found - ${cfg.siteName}`,
        description: 'This page does not exist.',
        urlPath: '/404',
        noindex: true,
      }),
    );
  }

  // DETAIL (satu halaman per wallpaper)
  for (const wp of wallpapers) {
    const jsonLd = JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'ImageObject',
      name: `${wp.character} - ${wp.title}`,
      description: wp.description || `${wp.character} wallpaper`,
      ...(siteUrl ? { contentUrl: siteUrl + wp.large, thumbnailUrl: siteUrl + wp.thumb } : {}),
      encodingFormat: wp.mime,
      width: wp.width,
      height: wp.height,
      datePublished: wp.date,
    }).replace(/</g, '\\u003c');

    let page = detailTpl;
    page = inject(page, 'VERSIONS', versionsHtml(wp));
    page = inject(page, 'CATEGORY_PILL', wp.category ? `<span class="pill">${esc(wp.category)}</span>` : '');
    page = inject(
      page,
      'TAGS',
      wp.tags.length ? `<ul class="tags" aria-label="Tags">${wp.tags.map((t) => `<li>${esc(t)}</li>`).join('')}</ul>` : '',
    );
    page = inject(page, 'CREDIT_LINE', wp.credit ? `<div><dt>Credit</dt><dd>${esc(wp.credit)}</dd></div>` : '');
    page = render(page, {
      ...baseVars,
      title: wp.title,
      character: wp.character,
      description: wp.description,
      resolution: wp.resolution,
      ratio: wp.ratio,
      format: wp.format,
      size: wp.size,
      date: wp.dateLabel,
      width: wp.width,
      height: wp.height,
      large: wp.large,
      largeW: wp.largeW,
      largeH: wp.largeH,
      download: wp.download,
      downloadName: wp.downloadName,
      bytes: wp.bytes,
      sha256: wp.sha256,
      artworkLabel: wp.artworkLabel,
      alt: altText(wp),
    });

    await write(
      `wallpaper/${wp.slug}.html`,
      wrapPage(page, 'gallery', {
        title: `${wp.character} - ${wp.title} wallpaper | ${cfg.siteName}`,
        description:
          wp.description ||
          `${wp.character} wallpaper. Download the original ${wp.resolution} ${wp.format} file.`,
        urlPath: wp.url,
        image: wp.og,
        imageAlt: `${wp.character} - ${wp.title}`,
        extra: `<script type="application/ld+json">${jsonLd}</script>`,
      }),
    );
  }

  // sitemap + robots (sitemap hanya jika domain publik sudah diisi)
  if (siteUrl) {
    const urls = [
      { loc: '/', lastmod: wallpapers[0]?.date },
      { loc: '/gallery', lastmod: wallpapers[0]?.date },
      { loc: '/about' },
      ...wallpapers.map((wp) => ({ loc: wp.url, lastmod: wp.date })),
    ];
    await write(
      'sitemap.xml',
      `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls
        .map((u) => `  <url><loc>${esc(siteUrl + u.loc)}</loc>${u.lastmod ? `<lastmod>${u.lastmod}</lastmod>` : ''}</url>`)
        .join('\n')}\n</urlset>\n`,
    );
  }
  await write(
    'robots.txt',
    `User-agent: *\nAllow: /\nDisallow: /original/\n${siteUrl ? `\nSitemap: ${siteUrl}/sitemap.xml\n` : ''}`,
  );

  // ringkasan
  console.log(`\n${cfg.siteName} - build selesai (${((Date.now() - started) / 1000).toFixed(1)} dtk)\n`);
  for (const wp of wallpapers) {
    console.log(
      `  ${wp.slug.padEnd(28)} ${wp.resolution.padEnd(16)} ${wp.format.padEnd(5)} ${wp.size.padStart(9)}  original OK (sha256 ${wp.sha256.slice(0, 12)}...)`,
    );
    for (const v of wp.variants) {
      console.log(
        `    + ${v.id.padEnd(26)} ${v.resolution.padEnd(16)} ${v.format.padEnd(5)} ${v.size.padStart(9)}  ${v.ratio.padEnd(6)} original OK`,
      );
    }
  }
  console.log(`\n  ${wallpapers.length} wallpaper -> ${path.relative(ROOT, P.dist)}/`);
  console.log(`  Panel Home: ${panel.empty ? 'placeholder (belum ada gambar)' : panel.src}`);
  if (warnings.length) {
    console.log('\n  Perlu perhatian:');
    for (const w of warnings) console.log(`   - ${w}`);
  }
  console.log('');
}

main().catch((err) => {
  if (err instanceof BuildError) {
    console.error(`\nERROR: ${err.message}\n`);
  } else {
    console.error(err);
  }
  process.exit(1);
});
