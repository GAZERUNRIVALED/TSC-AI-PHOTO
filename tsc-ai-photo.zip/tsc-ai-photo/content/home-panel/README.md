# Gambar panel di Home

Taruh gambar artwork-mu di folder ini (PNG dengan latar transparan sangat disarankan, JPG/WebP juga bisa).
Lalu buka `site.config.json` dan isi nama filenya:

```json
"homePanel": {
  "image": "nama-file-kamu.png",
  "alt": "Deskripsi singkat gambar",
  "caption": ""
}
```

- Kosongkan `"image"` untuk memakai placeholder bawaan.
- Panel ini terpisah dari galeri: mengganti gambar di sini tidak mengubah daftar wallpaper.
- Proporsi gambar dipertahankan (tidak di-crop).
