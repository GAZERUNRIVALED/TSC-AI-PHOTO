# TSC AI PHOTO

Galeri wallpaper AI bertema The Spike Cross (dan siap diperluas ke karakter, game, atau tema lain).
Website statis (HTML/CSS/JS), ringan, mobile-first, siap di-host di Cloudflare Pages.

File yang didownload pengunjung adalah **file original yang kamu upload**, disalin byte-per-byte
(tanpa resize, crop, kompresi ulang, atau konversi format).

Laporan pengujian ada di [`TESTING.md`](TESTING.md).

---

## 1. Fitur

- **Home:** hero, panel gambar kaca (glassmorphism) milikmu sendiri, Featured wallpapers, Recently added.
- **Gallery:** grid responsif, pencarian, filter kategori dan karakter, tombol "Show more" (lazy loading), seluruh kartu bisa diklik.
- **Detail wallpaper:** `/wallpaper/<slug>` dengan preview besar tanpa crop, metadata dari file asli, tombol Download Full Size, kredit, dan alat verifikasi hasil download.
- **About:** tujuan situs, cara kerja kredit, disclaimer non-afiliasi.
- **404:** halaman khusus dengan link berguna.
- **Glow teks selektif:** hanya pada judul tertentu, bisa diatur lewat variabel CSS.
- **SEO:** title dan description per halaman, Open Graph, favicon, canonical, sitemap, robots.txt (sitemap dan URL absolut aktif setelah `siteUrl` diisi).

## 2. Struktur proyek

```
tsc-ai-photo/
├── content/
│   ├── wallpapers.json       KATALOG wallpaper (edit di sini)
│   ├── originals/            FILE ORIGINAL wallpaper (jangan diubah/dikompres)
│   └── home-panel/           gambar untuk panel kaca di Home
├── site.config.json          pengaturan situs: domain, TikTok/YouTube, panel Home, kredit, disclaimer
├── scripts/
│   ├── build.mjs             membaca file asli, membuat preview, halaman, sitemap; menyalin original + cek checksum
│   ├── verify.mjs            memeriksa file yang disajikan identik dengan original
│   └── serve.mjs             server lokal untuk uji coba
├── src/
│   ├── pages/                isi halaman Home, Gallery, About, 404
│   ├── templates/            layout (navbar/footer) dan halaman detail wallpaper
│   └── static/               CSS, JS, favicon, _headers (aturan header Cloudflare)
├── package.json
└── dist/                     HASIL BUILD (dibuat otomatis, tidak masuk Git)
```

Isi `dist/` (situs yang tayang):

| Folder di `dist/` | Isi |
|---|---|
| `original/` | **file original**, nama rapi, dipakai tombol Download |
| `previews/` | preview kecil WebP (hanya untuk tampilan) |
| `og/` | gambar untuk pratinjau link di media sosial |
| `home-panel/` | salinan tampilan gambar panel Home |
| `data/wallpapers.json` | katalog publik berisi metadata + checksum SHA-256 |

## 3. Menambah wallpaper baru

Kamu cukup menambah **satu file gambar** dan **satu blok teks**. Resolusi, aspect ratio, ukuran file, dan format
**dibaca otomatis dari file asli** saat build. Jangan diisi manual.

1. **Folder file original:** `content/originals/`. Nama file bebas, contoh `isabel-neon.png`.
2. **Folder preview:** tidak perlu diisi. Preview dibuat otomatis ke `dist/previews/` saat build.
3. **Tambah entri** di `content/wallpapers.json` (jangan lupa koma di antara entri):

```json
{
  "title": "Neon Rain",
  "character": "Isabel",
  "file": "isabel-neon.png",
  "category": "Cyber",
  "tags": ["neon", "rain", "phone"],
  "featured": true,
  "artwork": "ai-generated",
  "description": "Isabel di tengah hujan neon.",
  "credit": "",
  "date": "2026-10-10"
}
```

| Field | Wajib | Keterangan |
|---|---|---|
| `title`, `character`, `file` | ya | `file` = nama file di `content/originals/` (huruf besar/kecil harus sama persis) |
| `category`, `tags` | tidak | dipakai untuk filter dan pencarian |
| `featured` | tidak | `true` = tampil di "Featured wallpapers" di Home |
| `artwork` | tidak | `ai-generated` (default), `fan-art`, atau `original`. Daftarnya ada di `artworkTypes` di `site.config.json` |
| `description`, `credit`, `date` | tidak | `date` format `YYYY-MM-DD`. Jika kosong dipakai tanggal file |
| `slug` | tidak | otomatis dari karakter + judul (`isabel-neon-rain`). Isi untuk URL kustom |

4. **Metadata akurat:** otomatis. Hasilnya bisa dilihat di `dist/data/wallpapers.json` (resolusi, rasio, ukuran, format, SHA-256).
5. **Slug dan URL:** dibuat dari karakter + judul. Contoh di atas menjadi `/wallpaper/isabel-neon-rain`. Slug harus unik. Kalau bentrok, build berhenti dengan pesan jelas.
6. **Nama file download:** otomatis `TSC-Isabel-Neon-Rain-1080x2340.png` (resolusi diambil dari file asli).
7. **Verifikasi hasil download:** lihat bagian 8.
8. **Uji sebelum publish:** lihat alur Android di bawah, atau bagian 6 (komputer).
9. **Publish:** commit ke GitHub. Cloudflare Pages membangun dan menayangkan otomatis (bagian 5).

### Alur dari HP Android (tanpa install apa pun)

1. Buka repository GitHub-mu di browser (Chrome, aktifkan "Situs desktop" jika menu upload tidak muncul).
2. Masuk ke folder `content/originals`, pilih **Add file, Upload files**, pilih gambar dari HP. Pilih **Create a new branch** (misalnya `wallpaper-baru`) lalu commit.
3. Pada branch yang sama, buka `content/wallpapers.json`, tekan ikon pensil, tambahkan blok entri, commit.
4. Cloudflare Pages otomatis membuat **Preview URL** untuk branch itu (lihat tab Deployments di dashboard Cloudflare). Buka di HP, cek halaman wallpaper dan tes tombol download.
5. Kalau sudah benar, buat Pull Request dan **Merge** ke branch utama. Situs produksi ter-update sendiri.

Kalau build gagal, buka log build di Cloudflare. Pesan kesalahan memakai bahasa Indonesia dan menyebut entri atau file yang bermasalah.

## 4. Mengganti gambar panel kaca di Home

Panel ini terpisah dari galeri, jadi mengganti gambarnya **tidak mengubah daftar wallpaper**.

1. Taruh gambar di folder `content/home-panel/` (PNG dengan latar transparan paling bagus, JPG/WebP juga bisa).
2. Buka `site.config.json` dan ubah bagian `homePanel`:

```json
"homePanel": {
  "image": "nama-file-kamu.png",
  "alt": "Deskripsi singkat gambar untuk pembaca layar",
  "caption": ""
}
```

3. Commit. Selesai. Proporsi gambar dipertahankan (`object-fit: contain`), tidak di-crop.
4. Kosongkan `"image"` untuk kembali ke placeholder bawaan. Jika nama file salah, build memberi peringatan dan memakai placeholder.

Catatan: gambar panel diproses menjadi salinan WebP (maks. lebar 1400 px) agar halaman Home ringan. Itu hanya untuk tampilan, bukan file download.

## 5. Deploy ke Cloudflare Pages (build otomatis lewat GitHub)

**Yang sudah selesai di proyek ini:** semua kode, `.node-version`, header Cloudflare (`_headers`), dan 404 khusus.

**Yang harus kamu lakukan:**

1. Buat akun GitHub dan repository baru, lalu upload isi folder proyek ini. (`node_modules`, `dist`, `.cache` sengaja tidak ikut, lihat `.gitignore`.)
2. Buat akun Cloudflare (gratis). Buka **Workers & Pages**, pilih **Create**, lalu **Pages**, dan hubungkan ke GitHub (**Connect to Git**). Pilih repository-nya. Tampilan menu Cloudflare bisa berubah, cari opsi yang sepadan.
3. Isi pengaturan build:
   - Framework preset: **None**
   - Build command: `npm run build`
   - Build output directory: `dist`
   - Environment variable (opsional): `NODE_VERSION` = `20`
4. **Save and Deploy.** Setelah selesai kamu mendapat URL seperti `https://nama-project.pages.dev`.
5. **Isi `siteUrl`** di `site.config.json` dengan URL itu (contoh `"siteUrl": "https://nama-project.pages.dev"`), lalu commit. Ini mengaktifkan canonical, Open Graph, dan sitemap.
6. **Isi link TikTok/YouTube** di `site.config.json` (`"tiktok"`, `"youtube"`). Selama kosong, link-nya disembunyikan supaya tidak ada tombol mati.
7. **Hapus 3 wallpaper SAMPLE** (di `wallpapers.json` dan file di `content/originals/`), lalu tambahkan wallpaper aslimu.

### Domain sendiri (nanti, opsional)

Di project Pages, buka **Custom domains**, **Set up a domain**, lalu ikuti petunjuk DNS Cloudflare. Setelah aktif, ubah `siteUrl` ke domain baru dan commit. Untuk path `/original/*`, biarkan fitur optimasi gambar Cloudflare (Polish, Mirage) mati agar file tidak diubah.

## 6. Menjalankan di komputer (opsional)

1. Pasang Node.js 18.17 atau lebih baru (https://nodejs.org, pilih LTS).
2. Di folder proyek:

```bash
npm install
npm run dev
```

3. Buka `http://localhost:8080`. Alamat untuk HP di Wi-Fi yang sama ikut tercetak di terminal, jadi kamu bisa melihat hasilnya di HP.
4. Build produksi saja: `npm run build` (hasil di `dist/`).
5. Setelah menambah wallpaper, hentikan (Ctrl+C) dan jalankan `npm run dev` lagi.

## 7. Mengatur glow teks

Glow hanya aktif pada elemen yang diberi class khusus. Paragraf, navigasi, metadata, dan deskripsi tidak diberi glow.

| Class | Dipakai untuk | Kekuatan |
|---|---|---|
| `.text-glow-primary` | judul brand utama di hero | terkuat |
| `.text-glow-accent` | judul bagian/halaman, nama brand di header | lebih halus |
| `.text-glow-violet` | aksen violet opsional (belum dipakai di halaman) | halus |
| `.text-glow-hover` | label interaktif, glow hanya saat hover/fokus | halus |

Pengaturan ada di bagian atas `src/static/css/style.css`:

```css
--glow-cyan: 63 224 255;           /* warna glow (RGB) */
--glow-blue: 47 123 255;
--glow-violet: 139 108 255;
--glow-primary-intensity: 1;       /* 0 = mati, 1 = default, 1.5 = lebih terang */
--glow-accent-intensity: 1;
```

Glow tidak beranimasi (tidak berkedip atau berdenyut). Transisi hover otomatis dimatikan jika pengguna memilih "kurangi gerakan".

## 8. Memastikan download benar-benar original

Lapisan perlindungan yang sudah ada:

- Tombol Download Full Size mengarah langsung ke `/original/<nama>.png`, salinan byte-per-byte dari `content/originals/`. Preview WebP tidak pernah dipakai untuk download.
- Saat build, setiap salinan diverifikasi dengan SHA-256. Build **gagal** jika ada satu byte pun yang beda.
- Sebelum mengunduh, browser memeriksa (HEAD, tanpa mengunduh isi file) bahwa file ada dan ukurannya sesuai katalog. Jika file hilang atau ukurannya beda, muncul pesan galat yang jelas dan **tidak ada preview yang diam-diam menggantikannya**.
- File original tidak diminta browser kecuali pengguna menekan tombol download.
- `Content-Disposition: attachment` di folder `/original/` (lihat `src/static/_headers`).

Cara memeriksa sendiri:

- **Di HP/browser (paling mudah):** buka halaman wallpaper, buka **Verify your download**, pilih file hasil download. Browser menghitung SHA-256 di perangkatmu (tidak ada yang diunggah) dan membandingkannya dengan original. Butuh halaman `https` atau `localhost`.
- **Di komputer, build lokal:** `npm run verify`
- **Di komputer, situs yang sudah online:** `npm run verify -- https://nama-project.pages.dev`. Mengunduh tiap original dari situs, lalu membandingkan checksum, ukuran, dan dimensi.

Catatan: aplikasi chat/galeri tertentu bisa mengompresi gambar saat dibagikan. Verifikasi file yang diunduh langsung dari situs.

## 9. Kredit dan non-afiliasi

Semua teks ada di `site.config.json`, jadi mudah diperbarui:

- `ipNotice`: kepemilikan The Spike Cross dan karakternya (menyebut SUNCYAN sebagai salah satu pemegang hak).
- `disclaimer`: pernyataan proyek fan independen, tidak berafiliasi atau didukung SUNCYAN.
- `artworkTypes` dan field `artwork` per wallpaper: membedakan karakter resmi dari artwork AI, fan art, atau karya orisinal.
- `credits`: daftar kredit di halaman About. Field `credit` per wallpaper menambah baris kredit khusus di halaman wallpaper.

Tidak ada lisensi, izin, atau dukungan yang dikarang. **Tolong periksa sendiri bahwa kalimatnya sesuai** dengan ketentuan pemegang hak The Spike Cross sebelum publish.

## 10. Troubleshooting

| Masalah | Penyebab dan solusi |
|---|---|
| Build gagal: "file ... tidak ditemukan" | Nama di `file` harus sama persis dengan file di `content/originals/`, termasuk huruf besar/kecil (server Cloudflare membedakan `Isabel.PNG` dan `isabel.png`) |
| Build gagal: "bukan JSON yang valid" | Biasanya kurang/lebih koma atau tanda kutip di `wallpapers.json`. Pesan menyebut baris dan kolomnya |
| Halaman wallpaper 404 setelah deploy | Pastikan Build output directory = `dist` dan build berhasil. Entri harus ada di `wallpapers.json` |
| Gambar tidak muncul di situs | Tekan refresh paksa. Cek di log build bahwa wallpaper terdaftar. Cek huruf besar/kecil nama file |
| Download gagal dengan pesan merah | File original tidak ada atau ukurannya tidak cocok di server. Cek deploy terakhir berhasil, lalu jalankan `npm run verify -- URL` |
| Cloudflare menolak file | Batas Cloudflare Pages: **25 MiB per file**. Lihat bagian 11 |
| Pratinjau link tidak muncul di media sosial | `siteUrl` belum diisi, atau cache media sosial masih lama. Isi `siteUrl`, deploy ulang, lalu uji ulang link |
| Font terlihat berbeda | Font dimuat dari Google Fonts. Jika diblokir, situs memakai font sistem |
| `npm install` gagal di komputer | Pastikan Node.js 18.17 atau lebih baru |

## 11. Batasan hosting statis

- Situs statis **tidak punya dashboard upload yang aman, akun pengguna, atau tagihan langganan**. Konten dikelola lewat GitHub (upload file + edit JSON). Dashboard upload membutuhkan backend dan autentikasi, dan tidak ditambahkan karena belum ada kebutuhan konkret.
- Cloudflare Pages membatasi **25 MiB per file** dan 20.000 file per situs. Original yang lebih besar perlu disimpan di tempat lain (misalnya Cloudflare R2). Untuk file di domain lain, atribut `download` diabaikan browser, jadi header `Content-Disposition` harus diatur oleh server penyimpanannya.
- Navigasi memakai tiga link yang selalu terlihat (tanpa menu hamburger) karena hanya ada tiga halaman, jadi tetap mudah dijangkau di HP dan bisa diakses keyboard. Jika halaman bertambah banyak, menu lipat perlu ditambahkan.
- Google Fonts adalah satu-satunya dependensi eksternal. Untuk menghilangkannya, unduh file font dan sajikan sendiri dari `src/static/`.
- Pencarian dan filter berjalan di browser dari halaman yang sudah dimuat. Ini cepat untuk ratusan wallpaper. Untuk ribuan, perlu strategi lain.
