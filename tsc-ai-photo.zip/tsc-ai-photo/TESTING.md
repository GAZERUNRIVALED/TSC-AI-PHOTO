# Laporan pengujian TSC AI PHOTO

Pengujian dijalankan di lingkungan sandbox (Node 22, Chromium lewat Playwright, `sharp` 0.34) terhadap server lokal
`scripts/serve.mjs`. Hanya yang benar-benar dijalankan yang ditulis "lulus". Sisanya ada di bagian "Perlu verifikasi manual".

Data uji: 3 wallpaper SAMPLE buatan sendiri (PNG 1080×2340, PNG 1440×3200, JPG 2560×1440). Bukan wallpaper aslimu.

## Ringkasan

| Tahap | Hasil |
|---|---|
| Build dari nol (zip diekstrak ke folder kosong, tanpa `.cache`) | berhasil, 3 wallpaper, checksum cocok |
| Pengujian otomatis konfigurasi default | 49 dari 49 lulus |
| Pengujian otomatis konfigurasi lengkap (domain, sosial, panel Home, paginasi) | 23 dari 23 lulus |
| `npm run verify` (lokal dan lewat HTTP ke server) | semua file identik dengan original |
| Pengujian jalur error build (file hilang, JSON rusak, JPG berputar EXIF) | lulus |

## Terverifikasi

### Desain visual
- Judul brand memakai glow terkuat. Judul bagian memakai glow lebih halus. Paragraf, navigasi, metadata, tombol, dan footer **tidak** punya `text-shadow` (dicek lewat computed style, hasilnya nol elemen).
- Panel kaca di Home memakai `backdrop-filter: blur`, tidak menimpa teks/tombol hero, dan tampil benar di 390, 768, dan 1280 px.
- Gambar panel: `object-fit: contain`, proporsi 800×1100 terjaga (diukur dari ukuran gambar yang tergambar). Placeholder tampil saat belum ada gambar.
- Mengganti gambar panel tidak mengubah katalog wallpaper (`dist/data/wallpapers.json` identik sebelum dan sesudah).
- Tidak ada overflow horizontal di lebar 320, 360, 390, 768, 1280, dan 1920 px pada Home, Gallery, About, dan dua halaman detail.
- Tinjauan visual lewat screenshot: Home (mobile dan desktop), bagian Featured, Gallery (mobile), dan bagian info Detail (mobile). Halaman About dan Detail di desktop diuji fungsinya, tetapi tampilannya tidak saya tinjau lewat screenshot untuk versi ini.

### Fungsi
- Rute 200: `/`, `/gallery`, `/about`, tiga `/wallpaper/<slug>` (dibuka langsung, bukan dari Home). Rute tidak dikenal memberi status 404 dengan halaman khusus (link ke Gallery, Home, dan 3 wallpaper terbaru).
- Klik di area gambar kartu membuka halaman detail yang benar (3 dari 3).
- Pencarian (judul, karakter, tag), filter kategori, filter karakter, kombinasi filter, keadaan kosong, tombol "Clear filters".
- Paginasi "Show more": dengan ukuran halaman 2 dan 3 wallpaper, tampil 2, lalu 3 setelah ditekan.
- Featured (2 wallpaper bertanda `featured`) dan Recently added tampil di Home. Link TikTok/YouTube tampil saat diisi dan tersembunyi saat kosong.
- Fitur lama yang dipertahankan: nama file download rapi, halaman detail, rasio/resolusi/ukuran/format otomatis, filter karakter, pembuatan preview.

### Integritas download
- Tombol download di halaman detail (3 wallpaper) dan di kartu galeri mengunduh file yang **byte-nya identik** dengan file di `content/originals/` (SHA-256 sama), nama file sesuai pola, dimensi sama (1080×2340, 1440×3200, 2560×1440), format sama (PNG, PNG, JPG).
- Saat file original sengaja dihilangkan dari server: tidak ada unduhan, muncul pesan "The original file could not be found ... not been replaced with a preview".
- Halaman Home, Gallery, detail, dan About dimuat tanpa satu pun permintaan ke `/original/`.
- Preview galeri memakai `/previews/*.webp`, atribut `loading="lazy"`, ada `width`/`height` dan teks `alt`.
- Alat "Verify your download": file original menghasilkan "Match", file lain (preview WebP) menghasilkan "No match".
- `npm run verify` lokal dan `npm run verify -- http://localhost:PORT`: checksum, ukuran, dan dimensi cocok untuk ketiga file.
- Header `/original/*` dari server lokal: `Content-Disposition: attachment`, `Content-Type` dan `Content-Length` sesuai file.

### Aksesibilitas dan performa
- Navigasi keyboard: tab ke link kartu menampilkan outline fokus yang terlihat.
- Mode "kurangi gerakan": durasi transisi menjadi 0.
- Target sentuh: semua link navigasi dan tombol setinggi minimal 40 px di layar 390 px.
- Gambar preview rusak: kartu menampilkan teks "Preview unavailable".
- Tidak ada error di console atau page error selama pengujian.
- Dependensi JavaScript: nol. Dependensi eksternal di halaman: hanya Google Fonts.

### Build dan SEO
- Dengan `siteUrl` terisi: canonical, `og:url`, `og:image` absolut, JSON-LD, `sitemap.xml` (6 URL), dan baris Sitemap di `robots.txt` muncul. Dengan `siteUrl` kosong: elemen berbasis URL absolut dilewati dan build memberi peringatan.
- JPG dengan orientasi EXIF 6 dibaca sebagai 900×1600 (sesuai tampilan di aplikasi galeri), file download tetap tidak diubah.
- Pesan galat build jelas untuk file hilang dan JSON rusak (dengan baris dan kolom).

## Perlu verifikasi manual (belum atau tidak bisa diuji di sini)

1. **Deploy nyata ke Cloudflare Pages.** Belum dilakukan. Routing `/gallery` dan `/wallpaper/<slug>` (tanpa `.html`) diuji di server lokal yang meniru perilaku Pages, bukan di Cloudflare sendiri. Setelah deploy, buka satu URL wallpaper langsung dan satu URL acak untuk melihat 404.
2. **Header Cloudflare (`_headers`).** Sintaksnya mengikuti dokumentasi, tetapi belum dicoba di Cloudflare. Cek bahwa `/original/...` dikirim sebagai attachment.
3. **Pemeriksaan ukuran sebelum download.** Kode membandingkan `Content-Length` dari permintaan HEAD dengan ukuran katalog. Kalau Cloudflare tidak mengirim header itu, pemeriksaan ukuran dilewati (kode sudah menanganinya) dan hanya pemeriksaan "file ada" yang berlaku. Jalankan `npm run verify -- URL` setelah deploy.
4. **Perangkat nyata.** Hanya Chromium dengan viewport tiruan yang diuji. Belum dicoba di Android Chrome, iPhone Safari, Firefox, atau tablet asli. Perilaku unduhan di iPhone (file masuk ke Files) dan kemulusan di Android kelas bawah perlu dicek langsung.
5. **Font.** Sandbox tidak punya internet, jadi Google Fonts (Syne, Instrument Sans) tidak termuat. Semua screenshot memakai font cadangan sistem, sehingga lebar teks dan tampilan glow bisa sedikit berbeda dari yang kamu lihat.
6. **Wallpaper aslimu.** Belum diuji dengan file besar (mendekati 25 MiB), puluhan wallpaper, atau banyak resolusi berbeda. Panel Home hanya diuji dengan PNG transparan potret. Gambar lanskap/lebar belum dicoba.
7. **Paginasi default.** Diuji dengan ukuran halaman 2. Perilaku dengan ukuran 12 dan lebih dari 12 wallpaper belum diuji langsung (logikanya sama).
8. **Pembaca layar** (TalkBack/VoiceOver) dan audit Lighthouse belum dijalankan. Kecepatan di jaringan lambat belum diukur.
9. **Pratinjau media sosial** (TikTok, WhatsApp, Facebook) baru bisa dicek setelah `siteUrl` diisi dan situs online.
10. **Alat "Verify your download"** butuh halaman `https` atau `localhost`. Di Cloudflare Pages (`https`) seharusnya berfungsi, tetapi belum diuji di sana.
11. **Isi kredit dan disclaimer** adalah teks bawaan dariku. Cocokkan dengan ketentuan pemegang hak The Spike Cross.

## Perubahan dari versi sebelumnya (dan alasannya)

- Tombol "View" terpisah di kartu dihapus karena seluruh kartu kini bisa diklik (diminta di spesifikasi), jadi fungsinya tetap ada. Tombol Download Full Size tetap ada di kartu.
- Panel tiga kartu di hero diganti panel gambar kaca (diminta di spesifikasi). Wallpaper terbaru tetap tampil di bagian Featured dan Recently added.
- Nama situs menjadi TSC AI PHOTO. Bisa diubah lewat `siteName` di `site.config.json`.
- Link TikTok/YouTube disembunyikan selama belum diisi (menghindari tombol mati). `siteUrl` kini kosong secara default supaya tidak memakai domain tebakan.
- Palet warna diganti ke hitam/navy dengan aksen cyan, biru elektrik, dan violet sesuai spesifikasi baru.
