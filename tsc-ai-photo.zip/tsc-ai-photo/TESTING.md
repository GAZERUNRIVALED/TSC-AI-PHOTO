# Laporan pengujian TSC AI PHOTO

Pengujian dijalankan di lingkungan sandbox (Node 22, Chromium lewat Playwright, `sharp` 0.34) terhadap server lokal
`scripts/serve.mjs`. Hanya yang benar-benar dijalankan yang ditulis "lulus". Sisanya ada di bagian "Perlu verifikasi manual".

Data uji tahap ini: 3 wallpaper SAMPLE buatan sendiri (PNG 1080×2340, PNG 1440×3200, JPG 2560×1440). Bukan wallpaper aslimu. Bagian ini dijalankan sebelum upgrade variasi dan **dijalankan ulang sebagai regresi** (49 dari 49 lulus, lihat di atas).

## Pembaruan: navigasi responsif dan tema Obsidian Violet (pengujian terbaru)

Semua angka berasal dari pengujian yang benar-benar dijalankan di sandbox (Chromium lewat Playwright, `sharp`, server lokal `scripts/serve.mjs`).
Data uji: 3 wallpaper SAMPLE dengan 7 file variasi. Wallpaper aslimu belum pernah diuji.

| Tahap | Hasil |
|---|---|
| Pengujian navigasi, tema, kontras, keyboard, safe area | 59 dari 59 lulus (lihat catatan 1) |
| Regresi fitur lama (rute, filter, paginasi, download, verifikasi, 404, overflow) | 49 dari 49 lulus (lihat catatan 2) |
| Pengujian variasi ukuran di 3 ukuran layar | 15 dari 15 lulus (lihat catatan 3) |
| `npm run build` | berhasil, 3 wallpaper, 10 file original, semua checksum cocok |
| `npm run verify` lokal dan lewat HTTP | 10 dari 10 file identik dengan original, batas 25 MiB lulus |

Catatan kejujuran:
1. Putaran pertama pengujian navigasi menghasilkan 58 dari 59. Yang gagal: pada mode "kurangi gerakan", transisi indikator tab aktif masih berjalan karena aturan CSS belum mencakup pseudo-element. Sudah diperbaiki, lalu semua diulang (59 dari 59).
2. Satu asersi lama diubah, bukan kodenya: tes lama menuntut glow judul minimal 3 lapis bayangan. Glow sengaja dikurangi menjadi 2 lapis yang lebih halus sesuai permintaan "hindari glow berlebihan", jadi syaratnya diubah menjadi 2 lapis. Fungsi lain tidak berubah.
3. Putaran pertama tes variasi menghasilkan 12 dari 15. Tiga yang gagal adalah salah asumsi di tes (mengira 5 pilihan versi, padahal 6: Original ditambah 5 variasi). Aplikasinya benar. Asumsi tes diperbaiki lalu diulang (15 dari 15).

### Navigasi (diuji di 15 ukuran layar)

Setiap ukuran diuji di 5 halaman (Home, Gallery, About, satu halaman detail, dan halaman 404):

- **Mobile portrait** 320×568, 360×740, 390×844, 430×932, dan batas 767×1000: bottom bar tetap menempel di dasar layar selebar layar, tinggi minimal 56px.
- **Mobile landscape** 568×320, 667×375, 844×390, dan 600×500: sidebar kiri selebar 72px setinggi layar, header tidak ikut menempel.
- **Tablet** 768×1024, 820×1180, 1024×768, 1180×820 dan **desktop** 1280×800, 1920×1080: sidebar kiri selebar 88px.
- Di semua ukuran: hanya ada satu elemen `<nav>`, tiga link (Home, Gallery, About) menuju alamat yang benar, masing-masing berikon, `aria-current` tepat pada halaman aktif (wallpaper detail menandai Gallery, halaman 404 tidak menandai apa pun), tidak ada overflow horizontal.
- Ikon berada di atas label pada sidebar.
- Tidak menutupi konten: setelah scroll ke dasar halaman, footer terlihat penuh di atas bottom bar (atau di sisi kanan sidebar). Tombol Download Full Size yang difokuskan keyboard tidak tertimpa navigasi.
- Safe area (disimulasikan dengan mengganti variabel `--safe-*`): bottom bar bertambah dari 64 menjadi 98px saat inset bawah 34px, padding body mengikuti, header menghormati inset atas, dan sidebar melebar menjadi 119px saat inset kiri 47px dengan item tetap di luar area notch.
- Keyboard: urutan Tab skip link, merek, Home, Gallery, About. Cincin fokus 2px solid violet terang. Enter pada link navigasi berpindah halaman.
- Tab aktif: garis indikator tampil (skala 1) sedangkan tab lain tersembunyi (skala 0), label violet terang, ada latar pil di belakang ikon. Transisi 0,2 detik, dan 0 detik pada mode "kurangi gerakan".

### Tema

- Nilai warna terhitung cocok dengan palet: latar `#090B12`, navigasi `#11131D`, kartu `#171525`, border `#2B293B`, teks `#F3F4F6`, teks sekunder `#A1A1AA`, tombol penting `#A78BFA`.
- Kontras WCAG (semua di atas 4,5:1): label nav tidak aktif 7,22:1, label nav aktif 10,02:1, teks utama 17,86:1, teks sekunder 7,67:1 (di kartu 7,00:1), teks tombol violet 6,74:1, link violet terang 10,65:1, cincin fokus 10,65:1.
- Glow judul berwarna violet, dua lapis, dan tidak ada `text-shadow` pada paragraf, navigasi, metadata, tombol, dan footer.
- Tidak ada sisa warna biru/cyan lama di CSS, HTML, favicon, maupun meta `theme-color`.
- Tinjauan visual lewat screenshot: Home mobile portrait (390×844), Home mobile landscape (844×390), detail mobile landscape (667×375), Home tablet portrait (768×1024), dan Gallery desktop (1280×800). Halaman lain di tiap ukuran diuji fungsinya, tetapi tidak semuanya saya tinjau lewat screenshot.

### Wallpaper dan unduhan

- File wallpaper tidak diubah oleh pembaruan ini. `npm run verify` mencocokkan SHA-256, ukuran, dan dimensi seluruh 10 file original, lokal dan lewat HTTP.
- Unduhan dari halaman detail (versi Mobile dan wallpaper satu versi) berisi byte yang identik dengan file aslinya di layar 390×844, 844×390, dan 1280×800.
- Fitur variasi ukuran tetap bekerja: pemilih menampilkan 6 pilihan (Original + 5 variasi) pada Isabel, dan tidak muncul pada wallpaper satu versi.

### Belum diuji

- Perangkat nyata (Android, iPhone) dan browser selain Chromium. Perilaku safe area sungguhan (notch, home indicator, gesture bar) hanya disimulasikan lewat variabel CSS. `viewport-fit=cover` sudah aktif, tetapi tampilan di iPhone/Android bertakik perlu dicek langsung.
- Pembaca layar (TalkBack/VoiceOver). Urutan keyboard dan atribut `aria-current` sudah diuji, tetapi pengalaman pembaca layar belum.
- Deploy nyata ke Cloudflare Pages. Header `_headers` dan routing tanpa `.html` belum dicoba di Cloudflare.
- Font Google tidak termuat di sandbox, jadi screenshot memakai font cadangan.
- Perubahan orientasi langsung (memutar HP saat halaman terbuka) belum dicoba. Tata letak berbasis media query, jadi seharusnya berganti otomatis.

## Upgrade: variasi ukuran wallpaper (pengujian terbaru)

Semua angka di bagian ini berasal dari pengujian yang benar-benar dijalankan di sandbox yang sama (Chromium lewat Playwright, `sharp`, server lokal).
Data uji: 3 wallpaper SAMPLE dengan 7 file variasi buatan sendiri (gradasi dengan teks "SAMPLE"), yaitu wallpaper dengan **satu versi** (Sanghyeon), **sebagian versi** (Ellio: Mobile dan Desktop), dan **semua lima versi** (Isabel, termasuk satu JPG).

| Tahap | Hasil |
|---|---|
| Pengujian browser pemilih versi | 59 dari 59 lulus |
| Pengujian jalur-gagal build (data salah) | 11 dari 11 sesuai harapan |
| Regresi fitur lama dengan data baru | 49 dari 49 lulus |
| Regresi fitur lama dengan **data lama persis** (3 wallpaper tanpa `variants`) | 49 dari 49 lulus, katalog 0 variasi, 3 file di `dist/original` |
| Pemilih versi dengan **konfigurasi lama** tanpa `variantTypes` (nilai bawaan) | 59 dari 59 lulus |
| `npm run build` | berhasil, 3 wallpaper, 10 file original (3 utama + 7 variasi), semua checksum cocok |
| `npm run verify` | 10 dari 10 file identik, batas 25 MiB lulus |
| Deteksi file melebihi 25 MiB (file uji sementara 25,8 MiB) | build memberi peringatan, `verify` gagal; file uji sudah dihapus lagi |

Terverifikasi pada halaman detail:

- Wallpaper satu versi: tidak ada pemilih, tidak ada blok data, tidak ada link tambahan. Judul, spesifikasi, tombol kembali, dan unduhan (byte identik, nama file sama seperti sebelumnya) tidak berubah.
- Sebagian dan semua versi: pemilih menampilkan tepat versi yang tersedia, urutannya sesuai konfigurasi, dan versi yang tidak ada (misalnya Tablet dan Modern Laptop pada Ellio) **tidak** ditampilkan.
- Untuk setiap versi: resolusi, format, dan ukuran file yang tampil sama dengan file sebenarnya (dibaca ulang dengan `sharp` dan ukuran file di disk). Preview adalah WebP dari `/previews/` dengan rasio yang sama. Tombol unduh menghasilkan file dengan **byte identik** dengan file versi itu, dimensi sama, dan nama file sesuai pola.
- Berpindah-pindah semua versi tanpa menekan unduh tidak memicu satu pun permintaan ke `/original/`.
- Kembali ke "Original" memulihkan tombol unduh lama. Original terpilih secara default.
- Tautan `?v=...` memilih versi yang benar. Nilai tidak dikenal atau versi yang tidak dimiliki wallpaper itu diabaikan. Memilih versi memperbarui alamat yang bisa dibagikan.
- Alat "Verify your download" mengikuti versi terpilih: file versi yang benar menghasilkan "Match", file lain "No match", dan hash yang tampil adalah hash versi itu.
- Keyboard: tombol panah memindahkan pilihan dan memperbarui halaman, fokus terlihat dengan outline.
- File original sebuah versi dihilangkan dari server: tombol unduh menampilkan pesan galat yang jelas, tidak ada unduhan, tidak ada preview pengganti.
- Tanpa JavaScript: pemilih tersembunyi, enam link unduh biasa tampil dan semuanya mengarah ke file original yang ada (status 200).
- Tidak ada overflow horizontal di 320, 360, 390, 768, 1280, dan 1920 px. Tombol versi setinggi minimal 44 px. Tidak ada error console.
- Tinjauan visual lewat screenshot: pemilih versi di mobile (390 px) dan desktop (1280 px).

Jalur gagal build yang diuji (semuanya berhenti dengan pesan jelas): id varian tidak dikenal, file varian tidak ada, `.PNG` vs `.png`, kapitalisasi nama berbeda (dengan petunjuk nama yang benar, juga untuk file utama), rasio tidak cocok kategori, isi file duplikat dari versi utama, ukuran di data tidak cocok file, `variants` berupa array, varian tanpa `file`, path keluar dari `content/originals/`.

Belum diuji untuk upgrade ini:

- Duplikat isi antar dua **variasi** (bukan dengan versi utama). Tidak ada dua kategori dengan rasio sama, jadi tidak bisa dibuat kasus ujinya. Logikanya sama dengan duplikat terhadap versi utama yang sudah diuji.
- Browser lama. Sorotan border versi terpilih memakai CSS `:has()` (Chrome 105+, Safari 15.4+, Firefox 121+). Di browser yang lebih lama, border tidak berubah tetapi warna teks versi terpilih tetap berubah karena memakai selektor lain.
- Safari iPhone, Android Chrome asli, dan Firefox. Hanya Chromium dengan viewport tiruan.
- Variasi dari wallpaper asli milikmu. Semua file variasi di sini buatan sandbox.
- Deploy nyata ke Cloudflare Pages (lihat daftar manual di bawah, tidak berubah).

Hasil pemeriksaan batas 25 MiB pada project ini: **tidak ada file yang melampaui batas**. File terbesar di `content/originals/` adalah `sanghyeon-dark.jpg` (177 KB) dan tidak ada file di `dist/` di atas 25 MiB. Tidak ada file yang dipindahkan dan arsitektur penyimpanan tidak diubah. Wallpaper aslimu belum ada di project ini, jadi pemeriksaan terhadap file nyatamu perlu dijalankan sendiri (`npm run verify` atau log build Cloudflare).

Catatan implementasi: spesifikasi menyebut "enam kategori" tetapi mendaftar lima rasio unik (sesuai catatan di spesifikasinya). Yang diimplementasikan adalah lima kelompok rasio dan lima id varian.

---

# Pengujian tahap sebelumnya (TSC AI PHOTO)

## Ringkasan

| Tahap | Hasil |
|---|---|
| Build dari nol (zip diekstrak ke folder kosong, tanpa `.cache`) | berhasil, 3 wallpaper, checksum cocok |
| Pengujian otomatis konfigurasi default | 49 dari 49 lulus |
| Pengujian otomatis konfigurasi lengkap (domain, sosial, panel Home, paginasi) | 23 dari 23 lulus |
| `npm run verify` (lokal dan lewat HTTP ke server) | semua file identik dengan original |
| Pengujian jalur error build (file hilang, JSON rusak, JPG berputar EXIF) | lulus |

## Terverifikasi

### Desain visual
- Judul brand memakai glow terkuat. Judul bagian memakai glow lebih halus. Paragraf, navigasi, metadata, tombol, dan footer **tidak** punya `text-shadow` (dicek lewat computed style, hasilnya nol elemen).
- Panel kaca di Home memakai `backdrop-filter: blur`, tidak menimpa teks/tombol hero, dan tampil benar di 390, 768, dan 1280 px.
- Gambar panel: `object-fit: contain`, proporsi 800×1100 terjaga (diukur dari ukuran gambar yang tergambar). Placeholder tampil saat belum ada gambar.
- Mengganti gambar panel tidak mengubah katalog wallpaper (`dist/data/wallpapers.json` identik sebelum dan sesudah).
- Tidak ada overflow horizontal di lebar 320, 360, 390, 768, 1280, dan 1920 px pada Home, Gallery, About, dan dua halaman detail.
- Tinjauan visual lewat screenshot: Home (mobile dan desktop), bagian Featured, Gallery (mobile), dan bagian info Detail (mobile). Halaman About dan Detail di desktop diuji fungsinya, tetapi tampilannya tidak saya tinjau lewat screenshot untuk versi ini.

### Fungsi
- Rute 200: `/`, `/gallery`, `/about`, tiga `/wallpaper/<slug>` (dibuka langsung, bukan dari Home). Rute tidak dikenal memberi status 404 dengan halaman khusus (link ke Gallery, Home, dan 3 wallpaper terbaru).
- Klik di area gambar kartu membuka halaman detail yang benar (3 dari 3).
- Pencarian (judul, karakter, tag), filter kategori, filter karakter, kombinasi filter, keadaan kosong, tombol "Clear filters".
- Paginasi "Show more": dengan ukuran halaman 2 dan 3 wallpaper, tampil 2, lalu 3 setelah ditekan.
- Featured (2 wallpaper bertanda `featured`) dan Recently added tampil di Home. Link TikTok/YouTube tampil saat diisi dan tersembunyi saat kosong.
- Fitur lama yang dipertahankan: nama file download rapi, halaman detail, rasio/resolusi/ukuran/format otomatis, filter karakter, pembuatan preview.

### Integritas download
- Tombol download di halaman detail (3 wallpaper) dan di kartu galeri mengunduh file yang **byte-nya identik** dengan file di `content/originals/` (SHA-256 sama), nama file sesuai pola, dimensi sama (1080×2340, 1440×3200, 2560×1440), format sama (PNG, PNG, JPG).
- Saat file original sengaja dihilangkan dari server: tidak ada unduhan, muncul pesan "The original file could not be found ... not been replaced with a preview".
- Halaman Home, Gallery, detail, dan About dimuat tanpa satu pun permintaan ke `/original/`.
- Preview galeri memakai `/previews/*.webp`, atribut `loading="lazy"`, ada `width`/`height` dan teks `alt`.
- Alat "Verify your download": file original menghasilkan "Match", file lain (preview WebP) menghasilkan "No match".
- `npm run verify` lokal dan `npm run verify -- http://localhost:PORT`: checksum, ukuran, dan dimensi cocok untuk ketiga file.
- Header `/original/*` dari server lokal: `Content-Disposition: attachment`, `Content-Type` dan `Content-Length` sesuai file.

### Aksesibilitas dan performa
- Navigasi keyboard: tab ke link kartu menampilkan outline fokus yang terlihat.
- Mode "kurangi gerakan": durasi transisi menjadi 0.
- Target sentuh: semua link navigasi dan tombol setinggi minimal 40 px di layar 390 px.
- Gambar preview rusak: kartu menampilkan teks "Preview unavailable".
- Tidak ada error di console atau page error selama pengujian.
- Dependensi JavaScript: nol. Dependensi eksternal di halaman: hanya Google Fonts.

### Build dan SEO
- Dengan `siteUrl` terisi: canonical, `og:url`, `og:image` absolut, JSON-LD, `sitemap.xml` (6 URL), dan baris Sitemap di `robots.txt` muncul. Dengan `siteUrl` kosong: elemen berbasis URL absolut dilewati dan build memberi peringatan.
- JPG dengan orientasi EXIF 6 dibaca sebagai 900×1600 (sesuai tampilan di aplikasi galeri), file download tetap tidak diubah.
- Pesan galat build jelas untuk file hilang dan JSON rusak (dengan baris dan kolom).

## Perlu verifikasi manual (belum atau tidak bisa diuji di sini)

1. **Deploy nyata ke Cloudflare Pages.** Belum dilakukan. Routing `/gallery` dan `/wallpaper/<slug>` (tanpa `.html`) diuji di server lokal yang meniru perilaku Pages, bukan di Cloudflare sendiri. Setelah deploy, buka satu URL wallpaper langsung dan satu URL acak untuk melihat 404.
2. **Header Cloudflare (`_headers`).** Sintaksnya mengikuti dokumentasi, tetapi belum dicoba di Cloudflare. Cek bahwa `/original/...` dikirim sebagai attachment.
3. **Pemeriksaan ukuran sebelum download.** Kode membandingkan `Content-Length` dari permintaan HEAD dengan ukuran katalog. Kalau Cloudflare tidak mengirim header itu, pemeriksaan ukuran dilewati (kode sudah menanganinya) dan hanya pemeriksaan "file ada" yang berlaku. Jalankan `npm run verify -- URL` setelah deploy.
4. **Perangkat nyata.** Hanya Chromium dengan viewport tiruan yang diuji. Belum dicoba di Android Chrome, iPhone Safari, Firefox, atau tablet asli. Perilaku unduhan di iPhone (file masuk ke Files) dan kemulusan di Android kelas bawah perlu dicek langsung.
5. **Font.** Sandbox tidak punya internet, jadi Google Fonts (Syne, Instrument Sans) tidak termuat. Semua screenshot memakai font cadangan sistem, sehingga lebar teks dan tampilan glow bisa sedikit berbeda dari yang kamu lihat.
6. **Wallpaper aslimu.** Belum diuji dengan file besar (mendekati 25 MiB), puluhan wallpaper, atau banyak resolusi berbeda. Panel Home hanya diuji dengan PNG transparan potret. Gambar lanskap/lebar belum dicoba.
7. **Paginasi default.** Diuji dengan ukuran halaman 2. Perilaku dengan ukuran 12 dan lebih dari 12 wallpaper belum diuji langsung (logikanya sama).
8. **Pembaca layar** (TalkBack/VoiceOver) dan audit Lighthouse belum dijalankan. Kecepatan di jaringan lambat belum diukur.
9. **Pratinjau media sosial** (TikTok, WhatsApp, Facebook) baru bisa dicek setelah `siteUrl` diisi dan situs online.
10. **Alat "Verify your download"** butuh halaman `https` atau `localhost`. Di Cloudflare Pages (`https`) seharusnya berfungsi, tetapi belum diuji di sana.
11. **Isi kredit dan disclaimer** adalah teks bawaan dariku. Cocokkan dengan ketentuan pemegang hak The Spike Cross.

## Perubahan dari versi sebelumnya (dan alasannya)

- Tombol "View" terpisah di kartu dihapus karena seluruh kartu kini bisa diklik (diminta di spesifikasi), jadi fungsinya tetap ada. Tombol Download Full Size tetap ada di kartu.
- Panel tiga kartu di hero diganti panel gambar kaca (diminta di spesifikasi). Wallpaper terbaru tetap tampil di bagian Featured dan Recently added.
- Nama situs menjadi TSC AI PHOTO. Bisa diubah lewat `siteName` di `site.config.json`.
- Link TikTok/YouTube disembunyikan selama belum diisi (menghindari tombol mati). `siteUrl` kini kosong secara default supaya tidak memakai domain tebakan.
- Palet warna diganti ke hitam/navy dengan aksen cyan, biru elektrik, dan violet sesuai spesifikasi saat itu. **Kemudian diganti lagi ke Obsidian Violet** (lihat bagian pembaruan di atas).
- Upgrade variasi ukuran: tombol, struktur data, dan unduhan wallpaper lama tidak diubah. Ditambahkan blok `variants` opsional, pemilih versi, kategori `variantTypes`, pemeriksaan nama file persis (huruf besar/kecil), peringatan 25 MiB, dan perluasan `npm run verify`. Rasio 16:10 kini tampil sebagai "16:10" (sebelumnya "8:5").
